import tkinter
import os

root = tkinter.Tk()
root.title('Quick Start')
root.minsize(230,200)

def launchMongo():
    os.system("cmd.exe /c mongo.bat")
    pass

def launchXampp():
    os.system("cmd.exe /c xampp.bat")
    pass

startMongo = tkinter.Button(root, text="Start Mongo", bg="green", fg='white', height=2, command=launchMongo).grid(row=0, column=0, pady=10, padx=20)
startXampp = tkinter.Button(root, text="Start XAMPP", bg="orange", fg='black', height=2, command=launchXampp).grid(row=0, column=1,  pady=10, padx=20)



root.mainloop()
